<?php include './inc/head.php' ?>
</head>

<body class="side-header" data-bs-spy="scroll" data-bs-target="#header-nav" data-bs-offset="1">

    <!-- Preloader -->
    <div class="preloader">
        <div class="lds-ellipsis">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
    <!-- Preloader End -->

    <!-- Document Wrapper   
=============================== -->
    <div id="main-wrapper">
     <?php include './inc/header.php' ?>

        <!-- Content
  ============================================= -->
        <div id="content" role="main">

            <!-- Intro
    ============================================= -->
            <section id="home">
                <div class="hero-wrap">
                    <div class="hero-mask opacity-8 bg-dark"></div>
                    <div class="hero-bg parallax" style="background-image:url('./assets/img/intro.jpg');"></div>
                    <div class="hero-content section d-flex min-vh-100">
                        <div class="container my-auto">
                            <div class="row">
                                <div class="col-12 text-center">
                                    <div class="typed-strings">
                                        <p>I'm Manthan Rawat</p>
                                        <p>I'm a Front-end Developer.</p>
                                        <p>I'm a Web designer.</p>
                                        <p>I'm a UI developer.</p>
                                    </div>
                                    <p class="text-7 fw-500 text-white mb-2 mb-md-3">Welcome</p>
                                    <h2 class="text-16 fw-600 text-white mb-2 mb-md-3"><span class="typed"></span></h2>
                                    <!-- <p class="text-5 text-light mb-4">Based in Uttar Pradesh.</p> -->
                                    <a href="tel:9889290880" class="btn btn-outline-primary rounded-pill shadow-none smooth-scroll mt-2">Hire Me</a>
                                </div>
                            </div>
                        </div>
                        <a href="#about" class="scroll-down-arrow text-white smooth-scroll"><span class="animated"><i class="fa fa-chevron-down"></i></span></a>
                    </div>
                </div>
            </section>
            <!-- Intro end -->

            <!-- About
    ============================================= -->
            <section id="about" class="section">
                <div class="container px-lg-5">
                    <!-- Heading -->
                    <div class="position-relative d-flex text-center mb-5">
                        <h2 class="text-24 text-light opacity-4 text-uppercase fw-600 w-100 mb-0">About Me</h2>
                        <p class="text-9 text-dark fw-600 position-absolute w-100 align-self-center lh-base mb-0">Know Me More<span class="heading-separator-line border-bottom border-3 border-primary d-block mx-auto"></span> </p>
                    </div>
                    <!-- Heading end-->

                    <div class="row gy-5">
                        <div class="col-lg-7 col-xl-8 text-center text-lg-start">
                            <h2 class="text-7 fw-600 mb-3">I'm <span class="text-primary">Manthan Rawat,</span> a Front-end Developer</h2>
                            <p>Experienced Front-End Developer with a strong background in creating visually appealing, user-friendly websites and web applications. </p>
                            <p>Proficient in HTML, CSS, Tailwind CSS, JavaScript, Jquery and frameworks like React & BootStrap. Skilled in responsive design, cross-browser compatibility, and optimizing performance. Passionate about delivering high-quality code and seamless user experiences.</p>
                        </div>
                        <div class="col-lg-5 col-xl-4">
                            <div class="ps-lg-4">
                                <ul class="list-style-2">
                                    <li class=""><span class="fw-600 me-2">Name:</span>Manthan Rawat</li>
                                    <li class=""><span class="fw-600 me-2">Email:</span><a href="mailto:manthanrawat3@gmail.com">manthanrawat3@gmail.com</a></li>
                                    <li class="border-0"><span class="fw-600 me-2">From:</span>Uattar pradesh, Prayagraj</li>
                                </ul>
                                <a href="manthanrawat.pdf" target="_blank" class="btn btn-primary rounded-pill">Download CV</a>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="brands-grid separator-border mt-5">
                        <div class="row">
                            <div class="col-6 col-md-3">
                                <div class="featured-box text-center">
                                    <h4 class="text-12 text-muted mb-0"><span class="counter" data-from="0" data-to="3">3</span>+</h4>
                                    <p class="mb-0">Years Experiance</p>
                                </div>
                            </div>
                            <div class="col-6 col-md-3">
                                <div class="featured-box text-center">
                                    <h4 class="text-12 text-muted mb-0"><span class="counter" data-from="0" data-to="250">250</span>+</h4>
                                    <p class="mb-0">Happy Clients</p>
                                </div>
                            </div>
                            <div class="col-6 col-md-3">
                                <div class="featured-box text-center">
                                    <h4 class="text-12 text-muted mb-0"><span class="counter" data-from="0" data-to="650">650</span>+</h4>
                                    <p class="mb-0">Projects Done</p>
                                </div>
                            </div>
                            <div class="col-6 col-md-3">
                                <div class="featured-box text-center">
                                    <h4 class="text-12 text-muted mb-0"><span class="counter" data-from="0" data-to="38">20</span></h4>
                                    <p class="mb-0">Get Awards</p>
                                </div>
                            </div>
                        </div>
                    </div> -->
                </div>
            </section>
            <!-- About end -->

            <!-- Services
    ============================================= -->
            <section id="services" class="section bg-light">
                <div class="container px-lg-5">
                    <!-- Heading -->
                    <div class="position-relative d-flex text-center mb-5">
                        <h2 class="text-24 text-light opacity-4 text-uppercase fw-600 w-100 mb-0">Services</h2>
                        <p class="text-9 text-dark fw-600 position-absolute w-100 align-self-center lh-base mb-0">What I Do?<span class="heading-separator-line border-bottom border-3 border-primary d-block mx-auto"></span> </p>
                    </div>
                    <!-- Heading end-->

                    <div class="row">
                        <div class="col-lg-11 mx-auto">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="featured-box style-3 mb-5">
                                        <div class="featured-box-icon text-primary bg-white shadow-sm rounded"> <i class="fas fa-palette"></i> </div>
                                        <h3>Web Design</h3>
                                        <p class="mb-0">I create visually appealing, user-centric websites that effectively communicate brand identity. My skills include designing responsive layouts, intuitive navigation, and interactive elements to enhance user experience. I am proficient in Figma and HTML/CSS, with a strong focus on typography and color theory.</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="featured-box style-3 mb-5">
                                        <div class="featured-box-icon text-primary bg-white shadow-sm rounded"> <i class="fas fa-desktop"></i></div>
                                        <h3>Costomize Template</h3>
                                        <p class="mb-0">Customizing a template website involves modifying a pre-designed template to fit your specific needs and preferences. This can include changing the layout, colors, fonts, images, and content to match your brand and style. Here's a brief outline of the steps involved.</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="featured-box style-3 mb-5">
                                        <div class="featured-box-icon text-primary bg-white shadow-sm rounded"> <i class="fas fa-pencil-ruler"></i> </div>
                                        <h3>UI/UX Design (figma)</h3>
                                        <p class="mb-0">UI/UX design in Figma involves using the platform's tools and features to create user interfaces (UI) and optimize user experiences (UX) for digital products like websites and mobile apps. Figma is a powerful design tool that allows designers to collaborate in real-time and create interactive prototypes. Here's a breakdown of the key aspects.</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="featured-box style-3 mb-5">
                                        <div class="featured-box-icon text-primary bg-white shadow-sm rounded"> <i class="fas fa-paint-brush"></i> </div>
                                        <h3>Project Develop</h3>
                                        <p class="mb-0">Developing a project involves a series of structured steps to turn an idea into a completed product or solution. Whether you're working on a web application, a mobile app, or any other type of project, the development process generally includes planning, design, development, testing, and launch phases</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="featured-box style-3 mb-5 mb-md-0">
                                        <div class="featured-box-icon text-primary bg-white shadow-sm rounded"> <i class="fas fa-chart-area"></i> </div>
                                        <h3>Team Work</h3>
                                        <p class="mb-0">Teamwork involves a group of individuals working collaboratively to achieve a common goal. Effective teamwork is crucial in project development and many other fields, as it leverages the diverse skills and perspectives of each team member.</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="featured-box style-3 mb-0">
                                        <div class="featured-box-icon text-primary bg-white shadow-sm rounded"> <i class="fas fa-bullhorn"></i> </div>
                                        <h3>Mobile Responsive</h3>
                                        <p class="mb-0">Mobile responsiveness refers to the design and development approach that ensures a website or web application looks and functions well on a variety of devices and screen sizes, particularly mobile phones and tablets.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Services end -->

            

            <!-- Resume
    ============================================= -->
            <section id="resume" class="section">
                <div class="container px-lg-5">
                    <!-- Heading -->
                    <div class="position-relative d-flex text-center mb-5">
                        <h2 class="text-24 text-light opacity-4 text-uppercase fw-600 w-100 mb-0">Summary</h2>
                        <p class="text-9 text-dark fw-600 position-absolute w-100 align-self-center lh-base mb-0">Resume<span class="heading-separator-line border-bottom border-3 border-primary d-block mx-auto"></span> </p>
                    </div>
                    <!-- Heading end-->

                    <div class="row gx-5">
                        <!-- My Education -->
                        <div class="col-md-6">
                            <h2 class="text-6 fw-600 mb-4">My Education</h2>
                            <div class="bg-white border rounded p-4 mb-4">
                                <p class="badge bg-primary text-2 fw-400">2015</p>
                                <h3 class="text-5">Intermediate/12th Grade Education</h3>
                                <p class="text-danger">DS School & collage</p>
                                <p class="mb-0">It seems like you might be asking about the "Intermediate" or "12th grade" level of education, which typically refers to the final year of secondary school in many educational systems.</p>
                            </div>
                            <div class="bg-white border rounded p-4 mb-4">
                                <p class="badge bg-primary text-2 fw-400">2015 - 2018</p>
                                <h3 class="text-5">Bachelor Degree(BA)</h3>
                                <p class="text-danger">University of Allahabad</p>
                                <p class="mb-0"> It signifies a foundational level of education in a specific field or discipline and serves as a stepping stone for further education or entry into the professional workforce.</p>
                            </div>
                            <div class="bg-white border rounded p-4 mb-4">
                                <p class="badge bg-primary text-2 fw-400">2018 - 2019</p>
                                <h3 class="text-5">Web Development Training</h3>
                                <p class="text-danger">IICS Collage</p>
                                <p class="mb-0">Web development is the process of creating and maintaining websites and web applications.</p>
                            </div>
                        </div>

                        <!-- My Experience -->
                        <div class="col-md-6">
                            <h2 class="text-6 fw-600 mb-4">My Experience</h2>
                            <div class="bg-white border rounded p-4 mb-4">
                                <p class="badge bg-primary text-2 fw-400">06/06/2021 - 10/06/2022</p>
                                <h3 class="text-5">Front-end developer</h3>
                                <p class="text-danger">Krafternoon</p>
                                <p class="mb-0">With ideas sprouting in the mind of young entrepreneur, Mr. Devarsh Srivastava planned to create platform which extends an approach towards Creative.</p>
                            </div>
                            <div class="bg-white border rounded p-4 mb-4">
                                <p class="badge bg-primary text-2 fw-400">14/07/2022 - 28/09/2023</p>
                                <h3 class="text-5">Front-end developer</h3>
                                <p class="text-danger">Xeam Ventures Pvt Ltd.</p>
                                <p class="mb-0">XEAM is a trusted brand among Indian PSUs, Central Government Departments, Mid & large sized corporate for its capabilities of delivering most efficient.</p>
                            </div>
                            <div class="bg-white border rounded p-4 mb-4">
                                <p class="badge bg-primary text-2 fw-400">03/10/2023 - 24/07/2024</p>
                                <h3 class="text-5">UI Developer</h3>
                                <p class="text-danger">Bonwic Technology</p>
                                <p class="mb-0">Bonwic Technologies is a leading digital marketing agency in Delhi.</p>
                            </div>
                        </div>
                    </div>
                    <!-- My Skills -->
                    <h2 class="text-6 fw-600 mt-4 mb-4">My Skills</h2>
                    <div class="row gx-5">
                        <div class="col-md-6">
                            <p class="text-dark fw-500 text-start mb-2">Web Design <span class="float-end">65%</span></p>
                            <div class="progress progress-sm mb-4">
                                <div class="progress-bar" role="progressbar" style="width: 65%" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="text-dark fw-500 text-start mb-2">HTML/CSS <span class="float-end">85%</span></p>
                            <div class="progress progress-sm mb-4">
                                <div class="progress-bar" role="progressbar" style="width: 85%" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="text-dark fw-500 text-start mb-2">JavaScript <span class="float-end">60%</span></p>
                            <div class="progress progress-sm mb-4">
                                <div class="progress-bar" role="progressbar" style="width: 60%" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <p class="text-dark fw-500 text-start mb-2">React JS <span class="float-end">40%</span></p>
                            <div class="progress progress-sm mb-4">
                                <div class="progress-bar" role="progressbar" style="width: 40%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="text-dark fw-500 text-start mb-2">Jquery<span class="float-end">75%</span></p>
                            <div class="progress progress-sm mb-4">
                                <div class="progress-bar" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="text-dark fw-500 text-start mb-2">Bootstrap <span class="float-end">80%</span></p>
                            <div class="progress progress-sm mb-4">
                                <div class="progress-bar" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center mt-5"><a href="manthanrawat.pdf" target="_blank" class="btn btn-outline-secondary rounded-pill shadow-none">Download CV <span class="ms-1"><i class="fas fa-download"></i></span></a></div>
                </div>
            </section>
            <!-- Resume end -->

            <!-- Portfolio
    ============================================= -->
<style>

    </style>

    <section id="portfolio" class="section bg-light">
      <div class="container px-lg-5"> 
        <!-- Heading -->
        <div class="position-relative d-flex text-center mb-5">
          <h2 class="text-24 text-light opacity-4 text-uppercase fw-600 w-100 mb-0">Portfolio</h2>
          <p class="text-9 text-dark fw-600 position-absolute w-100 align-self-center lh-base mb-0">My Work<span class="heading-separator-line border-bottom border-3 border-primary d-block mx-auto"></span> </p>
        </div>
        <!-- Heading end--> 
        <div class="row portfolio-filter g-4" >

            <!--Bonkerz Donkerz Product -->
            <div class="col-sm-12 col-lg-6 brand">
              <div class="portfolio-box rounded" data-bs-toggle="modal" data-bs-target="#bonkerzDonkerz">
                <div class="portfolio-img rounded"> <img class="img-fluid d-block" src="assets/img/bonker.webp" alt="">
                  <div class="portfolio-overlay">
                    <div class="portfolio-overlay-details">
                      <h5 class="text-white fw-400">Bonkerz Donkerz</h5>
                      <span class="text-light">E-commerce</span> </div>                      
                  </div>
                </div>
              </div>
            </div> 
            <!--End -->

            
            <!--Lalit Dalima Product -->
            <div class="col-sm-12 col-lg-6 brand">
              <div class="portfolio-box rounded" data-bs-toggle="modal" data-bs-target="#lalitdalmia">
                <div class="portfolio-img rounded"> <img class="img-fluid d-block" src="assets/img/lalit-daalima.webp" alt="">
                  <div class="portfolio-overlay">
                    <div class="portfolio-overlay-details">
                      <h5 class="text-white fw-400">Lalit Dalmia</h5>
                      <span class="text-light">Bridal Designers</span> </div>                      
                  </div>
                </div>
              </div>
            </div> 
            <!--End -->

            <!--kamIndia Product -->
            <div class="col-sm-12 col-lg-6 brand">
              <div class="portfolio-box rounded" data-bs-toggle="modal" data-bs-target="#kamIndia">
                <div class="portfolio-img rounded"> <img class="img-fluid d-block" src="assets/img/kaam-inda.webp" alt="">
                  <div class="portfolio-overlay">
                    <div class="portfolio-overlay-details">
                      <h5 class="text-white fw-400">kamIndia</h5>
                      <span class="text-light">Job POrtal</span> </div>                      
                  </div>
                </div>
              </div>
            </div> 
            <!--End -->


            <!--ciScientists Product -->
            <div class="col-sm-12 col-lg-6 brand">
              <div class="portfolio-box rounded" data-bs-toggle="modal" data-bs-target="#ciScientists">
                <div class="portfolio-img rounded"> <img class="img-fluid d-block" src="assets/img/ci-scientist.webp" alt="">
                  <div class="portfolio-overlay">
                    <div class="portfolio-overlay-details">
                      <h5 class="text-white fw-400">Ci Scientists</h5>
                      <span class="text-light">Pharma Competitive Intelligence</span> </div>                      
                  </div>
                </div>
              </div>
            </div> 
            <!--End -->


            <!--Black n Green Product -->
            <div class="col-sm-12 col-lg-6 brand">
              <div class="portfolio-box rounded" data-bs-toggle="modal" data-bs-target="#black_green">
                <div class="portfolio-img rounded"> <img class="img-fluid d-block" src="assets/img/bng.webp" alt="">
                  <div class="portfolio-overlay">
                    <div class="portfolio-overlay-details">
                      <h5 class="text-white fw-400">Black N Green</h5>
                      <span class="text-light">Mobile Technology</span> </div>                      
                  </div>
                </div>
              </div>
            </div> 
            <!--End -->




              <!--Kev Product -->
            <div class="col-sm-12 col-lg-6 brand">
              <div class="portfolio-box rounded" data-bs-toggle="modal" data-bs-target="#portKev">
                <div class="portfolio-img rounded"> <img class="img-fluid d-block" src="assets/img/kev-port.webp" alt="">
                  <div class="portfolio-overlay">
                    <div class="portfolio-overlay-details">
                      <h5 class="text-white fw-400">Kalpana Eklavya Vidyalayam </h5>
                      <span class="text-light">Education</span> </div>                      
                  </div>
                </div>
              </div>
            </div> 
            <!--End -->

        


            
          </div>
      </div>




    </section>
    

         

            <!-- Contact Me
    ============================================= -->
            <section id="contact" class="section bg-light">
                <div class="container px-lg-5">
                    <!-- Heading -->
                    <div class="position-relative d-flex text-center mb-5">
                        <h2 class="text-24 text-light opacity-4 text-uppercase fw-600 w-100 mb-0">Contact</h2>
                        <p class="text-9 text-dark fw-600 position-absolute w-100 align-self-center lh-base mb-0">Get in Touch<span class="heading-separator-line border-bottom border-3 border-primary d-block mx-auto"></span> </p>
                    </div>
                    <!-- Heading end-->
                    <div class="row gy-5">
                        <div class="col-md-4 col-xl-3 order-1 order-md-0 text-center text-md-start">
                            <h2 class="mb-3 text-5 text-uppercase">Address</h2>
                            <p class="text-3 mb-4">Naini Prayagraj<br>
                                Uttar Pradesh<br>
                                211008</p>
                            <p class="text-3 mb-1"><span class="text-primary text-4 me-2"><i class="fas fa-phone"></i></span>988 929 0880</p>
                            <p class="text-3 mb-4"><span class="text-primary text-4 me-2"><i class="fas fa-envelope"></i></span>manthanrawat3@gmail.com</p>
                            <h2 class="mb-3 text-5 text-uppercase">Follow Me</h2>
                            <ul class="social-icons justify-content-center justify-content-md-start">
                               
                                <li class="social-icons-twitter"><a data-bs-toggle="tooltip" href="https://instagram.com/creative_webdesigner_mnt/" target="_blank" title="Twitter"><i class="fab fa-instagram"></i></a></li>
                                <li class="social-icons-facebook"><a data-bs-toggle="tooltip" href="https://www.facebook.com/manthan.rawat.98" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
                              
                            </ul>
                        </div>
                        <div class="col-md-8 col-xl-9 order-0 order-md-1">
                            <h2 class="mb-3 text-5 text-uppercase text-center text-md-start">Send us a note</h2>
                            <form id="contact-form" action="php/mail.php" method="post">

                                <div class="row g-4">
                                    <div class="col-xl-6">
                                        <input name="name" type="text" class="form-control" required placeholder="Name">
                                    </div>
                                    <div class="col-xl-6">
                                        <input name="email" type="email" class="form-control" required placeholder="Email">
                                    </div>
                                    <div class="col">
                                        <textarea name="form-message" class="form-control" rows="5" required placeholder="Tell us more about your needs........"></textarea>
                                    </div>
                                </div>

                                <p class="text-center mt-4 mb-0">
                                    <button id="submit-btn" class="btn btn-primary rounded-pill d-inline-flex" type="submit">Send Message</button>
                                </p>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Contact Me end -->

        </div>
        <!-- Content end -->
<?php include './inc/footer.php' ?>

    </div>
    <!-- Document Wrapper end -->

    <!-- Back to Top
============================================= -->
    <a id="back-to-top" class="rounded-circle" data-bs-toggle="tooltip" title="Back to Top" href="javascript:void(0)"><i class="fa fa-chevron-up"></i></a>

    <!-- Terms & Policy Modal
================================== -->
    <div id="terms-policy" class="modal fade" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Terms & Policy</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <p>Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                    <h3 class="mb-3 mt-4 mt-4">Terms of Use</h3>
                    <p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Simply dummy text of the printing and typesetting industry.</p>
                    <h5 class="text-4 mt-4">Part I – Information Simone collects and controls</h5>
                    <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                    <h5 class="text-4 mt-4">Part II – Information that Simone processes on your behalf</h5>
                    <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                    <h5 class="text-4 mt-4">Part III – General</h5>
                    <p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                    <h3 class="mb-3 mt-4">Privacy Policy</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    <ol class="lh-lg">
                        <li>Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure.</li>
                        <li>Quidam lisque persius interesset his et, Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure.</li>
                        <li>In quot quidam persequeris vim, ad mea essent possim iriure. Quidam lisque persius interesset his et.</li>
                        <li>Quidam lisque persius interesset his et, Lisque persius interesset his et.</li>
                        <li>Interesset his et, Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure.</li>
                        <li>Persius interesset his et, Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure.</li>
                        <li>Quot quidam persequeris vim Quidam lisque persius interesset his et, Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure.</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- Terms & Policy Modal End -->

    <!-- Disclaimer Modal
================================== -->
    <div id="disclaimer" class="modal fade" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Copyright & Disclaimer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <p>Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    <ul class="lh-lg">
                        <li>Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure.</li>
                        <li>Quidam lisque persius interesset his et, Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure.</li>
                        <li>In quot quidam persequeris vim, ad mea essent possim iriure. Quidam lisque persius interesset his et.</li>
                        <li>Quidam lisque persius interesset his et, Lisque persius interesset his et.</li>
                        <li>Interesset his et, Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure.</li>
                        <li>Persius interesset his et, Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure.</li>
                        <li>Quot quidam persequeris vim Quidam lisque persius interesset his et, Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Disclaimer Modal End -->

   
<?php include './inc/script.php' ?>


<!--=====================Model Box Start From Here ===============-->




 <!--Black & Green -->
<div class="modal fade" id="black_green" tabindex="-1">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalXlLabel">Black N Green </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <div class ="row">
        <div class="col-md-7 col-sm-12">
          <img class="img-fluid d-block" src="assets/img/bng.webp" alt="">
        </div>
        <div class="col-md-5 col-sm-12">
            <h4 class="text-4 font-weight-600">Project Info:</h4>
            <p>blackNgreen is the leading mobile technology products company, empowering some of the biggest telecom operators around the world with its innovations.</p>
            <h4 class="text-4 font-weight-600 mt-4">Project Details:</h4>
              <ul class="list-style-2">
                <li><span class="text-dark font-weight-600 me-2">Client:</span>Black N Green </li>
                <li><span class="text-dark font-weight-600 me-2">Technologies:</span>HTML, css, Jquery, php</li>
                <li><span class="text-dark font-weight-600 me-2">Industry:</span>Mobile Technology</li>
                <li><span class="text-dark font-weight-600 me-2">URL:</span><a href="https://www.blackngreen.com/" target="_blank">https://www.blackngreen.com/</a></li>
              </ul>
        </div>
       </div>
      </div>     
    </div>
  </div>
</div>
<!--/ Ci Scientists India -->

 <!--Lalit dalmia -->
<div class="modal fade" id="lalitdalmia" tabindex="-1">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalXlLabel">Lalit Dalmia</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <div class ="row">
        <div class="col-md-7 col-sm-12">
          <img class="img-fluid d-block" src="assets/img/lalit-daalima.webp" alt="">
        </div>
        <div class="col-md-5 col-sm-12">
            <h4 class="text-4 font-weight-600">Project Info:</h4>
            <p>Lalit Dalmia is an Indian fashion designer from Delhi. He is known for his bridal and luxury wear.</p>
            <h4 class="text-4 font-weight-600 mt-4">Project Details:</h4>
              <ul class="list-style-2">
                <li><span class="text-dark font-weight-600 me-2">Client:</span>Lalit Dalmia</li>
                <li><span class="text-dark font-weight-600 me-2">Technologies:</span>nodejs, Nextjs, css</li>
                <li><span class="text-dark font-weight-600 me-2">Industry:</span>fashion designing</li>
                <li><span class="text-dark font-weight-600 me-2">URL:</span><a href="https://lalitdalmia.in/" target="_blank">https://lalitdalmia.in/</a></li>
              </ul>
        </div>
       </div>
      </div>     
    </div>
  </div>
</div>
<!--/ Lalit dalmia -->


<!--Ci Scientists -->
<div class="modal fade" id="ciScientists" tabindex="-1">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalXlLabel">Ci Scientists</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <div class ="row">
        <div class="col-md-7 col-sm-12">
          <img class="img-fluid d-block" src="assets/img/ci-scientist.webp" alt="">
        </div>
        <div class="col-md-5 col-sm-12">
            <h4 class="text-4 font-weight-600">Project Info:</h4>
            <p>We are a boutique consulting firm in the Pharma/Biotech/Med devices industry. We welcome both entry level and experienced professionals to join us.</p>
            <h4 class="text-4 font-weight-600 mt-4">Project Details:</h4>
              <ul class="list-style-2">
                <li><span class="text-dark font-weight-600 me-2">Client:</span>Ci Scientists</li>
                <li><span class="text-dark font-weight-600 me-2">Technologies:</span>HTML5, CSS3, laravel, Jquery</li>
                <li><span class="text-dark font-weight-600 me-2">Industry:</span>Pharma Competitive Intelligence</li>
                <li><span class="text-dark font-weight-600 me-2">URL:</span><a href="https://ciscientists.com/" target="_blank">https://ciscientists.com/</a></li>
              </ul>
        </div>
       </div>
      </div>     
    </div>
  </div>
</div>
<!--/ Ci Scientists India -->


<!--Bonkerz Donkerz -->
<div class="modal fade" id="bonkerzDonkerz" tabindex="-1">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalXlLabel">bonkerz Donkerz</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <div class ="row">
        <div class="col-md-7 col-sm-12">
          <img class="img-fluid d-block" src="assets/img/bonker.webp" alt="">
        </div>
        <div class="col-md-5 col-sm-12">
            <h4 class="text-4 font-weight-600">Project Info:</h4>
            <p>Once you successfully place your order, you will receive a confirmation email & SMS/WhatsApp with details of your order and your order ID.</p>
            <h4 class="text-4 font-weight-600 mt-4">Project Details:</h4>
              <ul class="list-style-2">
                <li><span class="text-dark font-weight-600 me-2">Client:</span>Bonkerz Donkerz</li>
                <li><span class="text-dark font-weight-600 me-2">Technologies:</span>HTML5, CSS3, laravel, Jquery</li>
                <li><span class="text-dark font-weight-600 me-2">Industry:</span>e-commerce</li>
                <li><span class="text-dark font-weight-600 me-2">URL:</span><a href="https://bonkerz.bonwic.cloud/" target="_blank">https://bonkerz.bonwic.cloud/</a></li>
              </ul>
        </div>
       </div>
      </div>     
    </div>
  </div>
</div>
<!--/ kaam India -->


<!--kaam India -->
<div class="modal fade" id="kamIndia" tabindex="-1">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalXlLabel">kaam India</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <div class ="row">
        <div class="col-md-7 col-sm-12">
          <img class="img-fluid d-block" src="assets/img/kaam-inda.webp" alt="">
        </div>
        <div class="col-md-5 col-sm-12">
            <h4 class="text-4 font-weight-600">Project Info:</h4>
            <p>Explore exciting job options at KaamIndia for a fulfilling career and employment solutions. Join us today and kickstart your journey to success.</p>
            <h4 class="text-4 font-weight-600 mt-4">Project Details:</h4>
              <ul class="list-style-2">
                <li><span class="text-dark font-weight-600 me-2">Client:</span>kaam India</li>
                <li><span class="text-dark font-weight-600 me-2">Technologies:</span>HTML5, CSS3, laravel, Jquery</li>
                <li><span class="text-dark font-weight-600 me-2">Industry:</span>Job Portal</li>
                <li><span class="text-dark font-weight-600 me-2">URL:</span><a href="https://kaamindia.co/" target="_blank">https://kaamindia.co/</a></li>
              </ul>
        </div>
       </div>
      </div>     
    </div>
  </div>
</div>
<!--/ kaam India -->



<!--Kalpana Eklavya Vidyalayam -->
<div class="modal fade" id="portKev" tabindex="-1">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalXlLabel">Kalpana Eklavya Vidyalayam</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <div class ="row">
        <div class="col-md-7 col-sm-12">
          <img class="img-fluid d-block" src="assets/img/kev-port.webp" alt="">
        </div>
        <div class="col-md-5 col-sm-12">
            <h4 class="text-4 font-weight-600">Project Info:</h4>
            <p>Located at Parnawan village, Sarmera block in Nalanda district of Bihar on Sarmera-Bihta Highway, our school is committed to meeting the educational needs.</p>
            <h4 class="text-4 font-weight-600 mt-4">Project Details:</h4>
              <ul class="list-style-2">
                <li><span class="text-dark font-weight-600 me-2">Client:</span>Kalpana Eklavya Vidyalayam</li>
                <li><span class="text-dark font-weight-600 me-2">Technologies:</span>HTML5, CSS3, PHP, Jquery</li>
                <li><span class="text-dark font-weight-600 me-2">Industry:</span>Education</li>
                <li><span class="text-dark font-weight-600 me-2">URL:</span><a href="http//kalpanaeklavyavidyalayam.com" target="_blank">http//kalpanaeklavyavidyalayam.com</a></li>
              </ul>
        </div>
       </div>
      </div>     
    </div>
  </div>
</div>
<!--/ Kalpana Eklavya Vidyalayam -->
<!--=====================Model Box End From Here ===============-->
</body>

</html>