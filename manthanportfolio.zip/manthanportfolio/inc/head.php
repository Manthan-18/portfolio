
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="./assets/img/fav.png" rel="icon" />
<title>Manthan Rawat -Portfolio</title>
<meta name="description" content="this is manthan rawat personal portfolio to show his work and experiance">
<meta name="author" content="https://manthanrawat.000webhostapp.com/">

<!-- Web Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

<!-- Stylesheet
============================== -->
<!-- Bootstrap -->
<link rel="stylesheet" type="text/css" href="./assets/css/bootstrap.min.css" />
<!-- Font Awesome Icon -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<!-- Owl Carousel -->
<link rel="stylesheet" type="text/css" href="./assets/css/owl.carousel.min.css" />
<!-- Magnific Popup -->
<link rel="stylesheet" type="text/css" href="./assets/css/magnific-popup.min.css" />
<!-- Custom Stylesheet -->
<link rel="stylesheet" type="text/css" href="./assets/css/style.css" />
<style>
    div[style*="z-index:9999999;"] {
      position: absolute !important;
    z-index: -1 !important;
}
</style>