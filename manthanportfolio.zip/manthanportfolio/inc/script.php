
    <!-- JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" integrity="sha512-RXf+QSDCUQs5uwRKaDoXt55jygZZm2V++WUZduaU/Ui/9EGp3f/2KZVahFZBKGH0s774sd3HmrhUy+SgOFQLVQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script src="./assets/js/jquery.min.js"></script>
    
    <script src="./assets/js/bootstrap.bundle.min.js"></script>
    <!-- Easing -->
    <script src="./assets/js/jquery.easing.min.js"></script>
    <!-- Appear -->
    <script src="./assets/js/jquery.appear.min.js"></script>
    <!-- Images Loaded -->
    <script src="./assets/js/imagesloaded.pkgd.min.js"></script>
    <!-- Counter -->
    <script src="./assets/js/jquery.countTo.min.js"></script>
    <!-- Parallax Bg -->
    <script src="./assets/js/parallaxie.min.js"></script>
    <!-- Typed -->
    <script src="./assets/js/typed.min.js"></script>
    <!-- Owl Carousel -->
    <script src="./assets/js/owl.carousel.min.js"></script>
    <!-- isotope Portfolio Filter -->
    <script src="./assets/js/isotope.pkgd.min.js"></script>
    <!-- Magnific Popup -->
    <script src="./assets/js/magnific-popup.min.js"></script>
    <!-- Custom Script -->
    <script src="./assets/js/script.js"></script>